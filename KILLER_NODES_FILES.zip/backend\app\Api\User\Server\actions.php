<?php

/*
 * This file is part of MythicalDash.
 *
 * MIT License
 *
 * Copyright (c) 2020-2025 MythicalSystems
 * Copyright (c) 2020-2025 Cassian Gherman (NaysKutzu)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * Please rather than modifying the dashboard code try to report the thing you wish on our github or write a plugin
 */

use MythicalDash\App;
use MythicalDash\Permissions;
use MythicalDash\Chat\Eggs\Eggs;
use MythicalDash\Chat\User\User;
use MythicalDash\Chat\Images\Image;
use MythicalDash\Chat\User\Session;
use MythicalDash\Config\ConfigInterface;
use MythicalDash\Chat\Eggs\EggCategories;
use MythicalDash\Chat\columns\UserColumns;
use MythicalDash\Chat\Locations\Locations;
use MythicalDash\Chat\Servers\ServerQueue;
use MythicalDash\Chat\User\UserActivities;
use MythicalDash\CloudFlare\CloudFlareRealIP;
use MythicalDash\Hooks\Pterodactyl\Admin\Servers;
use MythicalDash\Plugins\Events\Events\ServerEvent;
use MythicalDash\Chat\interface\UserActivitiesTypes;
use MythicalDash\Plugins\Events\Events\ServerQueueEvent;
use MythicalDash\Hooks\MythicalSystems\CloudFlare\Turnstile;

// Update server
$router->post('/api/user/server/(.*)/update', function (string $id): void {
    App::init();
    $appInstance = App::getInstance(true);
    $appInstance->allowOnlyPOST();
    $session = new Session($appInstance);
    $accountToken = $session->SESSION_KEY;
    $pterodactylUserId = User::getInfo($accountToken, UserColumns::PTERODACTYL_USER_ID, false);

    // Get the server first to check ownership
    $server = Servers::getServerPterodactylDetails((int) $id);

    if (!$server) {
        $appInstance->Forbidden('Server not found or you do not have permission to access it', ['error_code' => 'SERVER_NOT_FOUND']);

        return;
    }

    $pterodactylUserId = $session->getInfo(UserColumns::PTERODACTYL_USER_ID, false);
    $owner = $server['attributes']['user'];
    if ($owner != $pterodactylUserId) {
        $appInstance->Forbidden('You do not have permission to access this server', ['error_code' => 'FORBIDDEN']);

        return;
    }

    // Add additional server information
    $locationId = $server['attributes']['relationships']['location']['attributes']['id'];
    $location = Locations::getLocationByPterodactylLocationId($locationId);
    $server['location'] = $location;

    $eggId = $server['attributes']['relationships']['egg']['attributes']['id'];
    $egg = Eggs::getByPterodactylEggId($eggId);
    $server['service'] = $egg;

    $nestId = $server['attributes']['relationships']['nest']['attributes']['id'];
    $nest = EggCategories::getByPterodactylNestId($nestId);
    $server['category'] = $nest;
    $allocation = $server['attributes']['allocation'];

    // Validate input data
    if (isset($_POST['name']) && !empty($_POST['name'])) {
        $name = $_POST['name'];
    } else {
        $appInstance->BadRequest('Name is required', ['error_code' => 'NAME_REQUIRED']);

        return;
    }
    if (isset($_POST['description']) && !empty($_POST['description'])) {
        $description = $_POST['description'];
    } else {
        $appInstance->BadRequest('Description is required', ['error_code' => 'DESCRIPTION_REQUIRED']);

        return;
    }
    // Validate memory field
    if (!isset($_POST['memory'])) {
        $appInstance->BadRequest('Memory is required', ['error_code' => 'MEMORY_REQUIRED']);

        return;
    }

    if (!is_numeric($_POST['memory'])) {
        $appInstance->BadRequest('Memory must be a numeric value', ['error_code' => 'MEMORY_INVALID_TYPE']);

        return;
    }

    $memory = (int) $_POST['memory'];

    // Validate that memory is not negative
    if ($memory < 0) {
        $appInstance->BadRequest('Memory cannot be a negative number', ['error_code' => 'MEMORY_NEGATIVE']);

        return;
    }

    if (isset($_POST['cpu']) && !empty($_POST['cpu'])) {
        $cpu = (int) $_POST['cpu'];
    } else {
        $appInstance->BadRequest('CPU is required', ['error_code' => 'CPU_REQUIRED']);

        return;
    }

    // Validate that CPU is not negative
    if ($cpu < 0) {
        $appInstance->BadRequest('CPU cannot be a negative number', ['error_code' => 'CPU_NEGATIVE']);

        return;
    }
    if (isset($_POST['disk']) && !empty($_POST['disk'])) {
        $disk = (int) $_POST['disk'];
    } else {
        $appInstance->BadRequest('Disk is required', ['error_code' => 'DISK_REQUIRED']);

        return;
    }

    // Validate that disk is not negative
    if ($disk < 0) {
        $appInstance->BadRequest('Disk cannot be a negative number', ['error_code' => 'DISK_NEGATIVE']);

        return;
    }
    if (isset($_POST['databases']) && !empty($_POST['databases'])) {
        $databases = max(0, intval($_POST['databases']));
    } else {
        // Servers may not require databases
        $databases = 0;
    }
    // Validate that databases is not negative
    if ($databases < 0) {
        $appInstance->BadRequest('Databases cannot be a negative number', ['error_code' => 'DATABASES_NEGATIVE']);

        return;
    }
    // Validate backups field
    if (!isset($_POST['backups'])) {
        $appInstance->BadRequest('Backups is required', ['error_code' => 'BACKUPS_REQUIRED']);

        return;
    }

    if (!is_numeric($_POST['backups'])) {
        $appInstance->BadRequest('Backups must be a numeric value', ['error_code' => 'BACKUPS_INVALID_TYPE']);

        return;
    }

    $backups = (int) $_POST['backups'];

    // Validate that backups is not negative
    if ($backups < 0) {
        $appInstance->BadRequest('Backups cannot be a negative number', ['error_code' => 'BACKUPS_NEGATIVE']);

        return;
    }
    if (isset($_POST['allocations']) && !empty($_POST['allocations'])) {
        $allocations = $_POST['allocations'];
    } else {
        $appInstance->BadRequest('Allocations is required', ['error_code' => 'ALLOCATIONS_REQUIRED']);

        return;
    }

    // Validate that allocations is not negative
    if ($allocations < 0) {
        $appInstance->BadRequest('Allocations cannot be a negative number', ['error_code' => 'ALLOCATIONS_NEGATIVE']);

        return;
    }

    // Validate required fields
    if (empty($name)) {
        $appInstance->BadRequest('Name is required', ['error_code' => 'NAME_REQUIRED']);

        return;
    }

    // Validate resource limits
    if ($memory < 256) {
        $appInstance->BadRequest('Memory must be at least 256MB', ['error_code' => 'MEMORY_MINIMUM']);

        return;
    }

    if ($cpu < 5) {
        $appInstance->BadRequest('CPU must be at least 5%', ['error_code' => 'CPU_MINIMUM']);

        return;
    }

    if ($disk < 256) {
        $appInstance->BadRequest('Disk must be at least 256MB', ['error_code' => 'DISK_MINIMUM']);

        return;
    }

    if ($allocations < 1) {
        $appInstance->BadRequest('Allocations must be at least 1', ['error_code' => 'ALLOCATIONS_MINIMUM']);

        return;
    }

    $resources = Servers::getUserTotalResourcesUsage($pterodactylUserId);
    $available_resources = User::getInfoArray($accountToken, [
        UserColumns::MEMORY_LIMIT,
        UserColumns::DISK_LIMIT,
        UserColumns::CPU_LIMIT,
        UserColumns::DATABASE_LIMIT,
        UserColumns::BACKUP_LIMIT,
        UserColumns::ALLOCATION_LIMIT,
        UserColumns::SERVER_LIMIT,
    ], []);

    // Get current server resources to calculate the difference
    $currentServerResources = [
        'memory' => $server['attributes']['limits']['memory'],
        'disk' => $server['attributes']['limits']['disk'],
        'cpu' => $server['attributes']['limits']['cpu'],
        'databases' => $server['attributes']['feature_limits']['databases'],
        'backups' => $server['attributes']['feature_limits']['backups'],
        'allocations' => $server['attributes']['feature_limits']['allocations'],
    ];

    // Calculate resource difference (new - current)
    $resourceDifference = [
        'memory' => $memory - $currentServerResources['memory'],
        'disk' => $disk - $currentServerResources['disk'],
        'cpu' => $cpu - $currentServerResources['cpu'],
        'databases' => $databases - $currentServerResources['databases'],
        'backups' => $backups - $currentServerResources['backups'],
        'allocations' => $allocations - $currentServerResources['allocations'],
    ];

    // Check if the update would exceed available resources
    if ($resourceDifference['memory'] > 0) {
        $freeMemory = $available_resources[UserColumns::MEMORY_LIMIT] - $resources['memory'];
        if ($resourceDifference['memory'] > $freeMemory) {
            $appInstance->BadRequest('This update would exceed your maximum memory limit', [
                'error_code' => 'MAX_MEMORY_LIMIT',
                'required' => $available_resources[UserColumns::MEMORY_LIMIT],
                'current_usage' => $resources['memory'],
                'attempted_to_add' => $resourceDifference['memory'],
            ]);

            return;
        }
    }

    if ($resourceDifference['disk'] > 0) {
        $freeDisk = $available_resources[UserColumns::DISK_LIMIT] - $resources['disk'];
        if ($resourceDifference['disk'] > $freeDisk) {
            $appInstance->BadRequest('This update would exceed your maximum disk limit', [
                'error_code' => 'MAX_DISK_LIMIT',
                'required' => $available_resources[UserColumns::DISK_LIMIT],
                'current_usage' => $resources['disk'],
                'attempted_to_add' => $resourceDifference['disk'],
            ]);

            return;
        }
    }

    if ($resourceDifference['cpu'] > 0) {
        $freeCpu = $available_resources[UserColumns::CPU_LIMIT] - $resources['cpu'];
        if ($resourceDifference['cpu'] > $freeCpu) {
            $appInstance->BadRequest('This update would exceed your maximum CPU limit', [
                'error_code' => 'MAX_CPU_LIMIT',
                'required' => $available_resources[UserColumns::CPU_LIMIT],
                'current_usage' => $resources['cpu'],
                'attempted_to_add' => $resourceDifference['cpu'],
            ]);

            return;
        }
    }

    if ($resourceDifference['databases'] > 0 && $available_resources[UserColumns::DATABASE_LIMIT] >= 0) {
        $freeDatabases = $available_resources[UserColumns::DATABASE_LIMIT] - $resources['databases'];
        if ($resourceDifference['databases'] > $freeDatabases) {
            $appInstance->BadRequest('This update would exceed your maximum databases limit', [
                'error_code' => 'MAX_DATABASES_LIMIT',
                'required' => $available_resources[UserColumns::DATABASE_LIMIT],
                'current_usage' => $resources['databases'],
                'attempted_to_add' => $resourceDifference['databases'],
            ]);

            return;
        }
    }

    if ($resourceDifference['backups'] > 0 && $available_resources[UserColumns::BACKUP_LIMIT] >= 0) {
        $freeBackups = $available_resources[UserColumns::BACKUP_LIMIT] - $resources['backups'];
        if ($resourceDifference['backups'] > $freeBackups) {
            $appInstance->BadRequest('This update would exceed your maximum backups limit', [
                'error_code' => 'MAX_BACKUPS_LIMIT',
                'required' => $available_resources[UserColumns::BACKUP_LIMIT],
                'current_usage' => $resources['backups'],
                'attempted_to_add' => $resourceDifference['backups'],
            ]);

            return;
        }
    }

    if ($resourceDifference['allocations'] > 0) {
        $freeAllocations = $available_resources[UserColumns::ALLOCATION_LIMIT] - $resources['allocations'];
        if ($resourceDifference['allocations'] > $freeAllocations) {
            $appInstance->BadRequest('This update would exceed your maximum allocations limit', [
                'error_code' => 'MAX_ALLOCATIONS_LIMIT',
                'required' => $available_resources[UserColumns::ALLOCATION_LIMIT],
                'current_usage' => $resources['allocations'],
                'attempted_to_add' => $resourceDifference['allocations'],
            ]);

            return;
        }
    }

    // Update server details
    try {
        $updateData = [
            'allocation' => $allocation,
            'memory' => $memory,
            'cpu' => $cpu,
            'swap' => 0,
            'io' => 500,
            'disk' => $disk,
            'feature_limits' => [
                'databases' => $databases,
                'backups' => $backups,
                'allocations' => $allocations,
            ],
        ];

        $details = [
            'name' => $name,
            'user' => $pterodactylUserId,
            'description' => $description,
            'external_id' => '',
        ];
        if (!isset($server['attributes']['id'])) {
            $appInstance->BadRequest('Server not found', ['error_code' => 'SERVER_NOT_FOUND']);

            return;
        }
        $serverId = $server['attributes']['id'];
        $svAw1 = Servers::updatePterodactylServer($serverId, $updateData);
        $svAw2 = Servers::updatePterodactylServerDetails($serverId, $details);
        global $eventManager;
        $eventManager->emit(ServerEvent::onServerUpdated(), [
            'server' => $server,
            'updateData' => $updateData,
            'details' => $details,
        ]);
        UserActivities::add(
            $session->getInfo(UserColumns::UUID, false),
            UserActivitiesTypes::$server_update,
            CloudFlareRealIP::getRealIP(),
            "Updated server $serverId"
        );
        $appInstance->OK('Server updated successfully', [
            'build' => $updateData,
            'details' => $details,
            'server' => $server,
            'rsp' => [
                'svAw1' => $svAw1,
                'svAw2' => $svAw2,
            ],
        ]);

    } catch (Exception $e) {
        $appInstance->ServiceUnavailable('Error updating server: ' . $e->getMessage(), ['error_code' => 'FAILED_TO_UPDATE_SERVER']);
    }
});

// Renew server
$router->post('/api/user/server/(.*)/renew', function (string $id): void {
    App::init();
    $appInstance = App::getInstance(true);
    $appInstance->allowOnlyPOST();
    $session = new Session($appInstance);
    $config = $appInstance->getConfig();

    // Check if server renewal is enabled
    if ($config->getDBSetting(ConfigInterface::SERVER_RENEW_ENABLED, 'false') == 'false') {
        $appInstance->BadRequest('Server renewal is not enabled', ['error_code' => 'SERVER_RENEWAL_NOT_ENABLED']);

        return;
    }

    // Get server details
    $server = Servers::getServerPterodactylDetails((int) $id);
    if (!$server) {
        $appInstance->Forbidden('Server not found or you do not have permission to access it', ['error_code' => 'SERVER_NOT_FOUND']);

        return;
    }

    // Verify ownership
    $pterodactylUserId = $session->getInfo(UserColumns::PTERODACTYL_USER_ID, false);
    $owner = $server['attributes']['user'];
    if ($owner != $pterodactylUserId) {
        $appInstance->Forbidden('You do not have permission to access this server', ['error_code' => 'FORBIDDEN']);

        return;
    }

    // Get server info from database
    if (isset($server['attributes']['id'])) {
        $serverId = $server['attributes']['id'];
        $serverInfoDb = MythicalDash\Chat\Servers\Server::getByPterodactylId((int) $serverId);
        if (!$serverInfoDb) {
            $appInstance->BadRequest('Server not found in database', ['error_code' => 'SERVER_NOT_FOUND_IN_DB']);

            return;
        }
    }

    // Get renewal settings
    $server_renew_cost = (int) $config->getDBSetting(ConfigInterface::SERVER_RENEW_COST, 120);
    $server_renew_days = (int) $config->getDBSetting(ConfigInterface::SERVER_RENEW_DAYS, 30);

    // Validate renewal settings
    if ($server_renew_cost <= 0) {
        $appInstance->BadRequest('Invalid renewal cost configuration', ['error_code' => 'INVALID_RENEWAL_COST']);

        return;
    }

    if ($server_renew_days <= 0) {
        $appInstance->BadRequest('Invalid renewal days configuration', ['error_code' => 'INVALID_RENEWAL_DAYS']);

        return;
    }

    // Check user balance atomically to prevent race conditions
    $creditCheck = $session->checkCreditsAtomic($server_renew_cost);
    if (!$creditCheck['has_sufficient']) {
        $appInstance->BadRequest('You do not have enough credits to renew this server', [
            'error_code' => 'INSUFFICIENT_CREDITS',
            'required' => $server_renew_cost,
            'available' => $creditCheck['current_credits'],
        ]);

        return;
    }

    // Calculate new expiration date
    $currentExpiresAt = strtotime($serverInfoDb['expires_at']);
    if ($currentExpiresAt === false) {
        $appInstance->BadRequest('Invalid server expiration date', ['error_code' => 'INVALID_EXPIRATION_DATE']);

        return;
    }

    $newExpiresAt = $currentExpiresAt + ($server_renew_days * 86400); // Convert days to seconds
    $newExpiresAtFormatted = date('Y-m-d H:i:s', $newExpiresAt);

    try {
        // Update server expiration
        if (!MythicalDash\Chat\Servers\Server::update($serverInfoDb['id'], $newExpiresAt)) {
            throw new Exception('Failed to update server expiration');
        }

        // Remove credits atomically to prevent race conditions
        if (!$session->removeCreditsAtomic($server_renew_cost)) {
            // If removing credits failed, we need to rollback the server expiration update
            // This is a critical error that should be logged
            $appInstance->getLogger()->error('Failed to remove renewal credits atomically for user: ' . $session->getInfo(UserColumns::UUID, false) . ' for server: ' . $serverId);
            $appInstance->BadRequest('Failed to process renewal - credit deduction failed', ['error_code' => 'CREDIT_DEDUCTION_FAILED']);

            return;
        }

        // Log activity
        UserActivities::add(
            $session->getInfo(UserColumns::UUID, false),
            UserActivitiesTypes::$server_renew,
            CloudFlareRealIP::getRealIP(),
            "Renewed server $serverId for $server_renew_days days"
        );

        // Emit event
        global $eventManager;
        $eventManager->emit(ServerEvent::onServerRenewed(), [
            'server' => $server,
            'renewal_days' => $server_renew_days,
            'cost' => $server_renew_cost,
            'new_expires_at' => $newExpiresAtFormatted,
        ]);

        // Return success response
        $appInstance->OK('Server renewed successfully', [
            'server' => $serverInfoDb,
            'renewal_details' => [
                'days_added' => $server_renew_days,
                'cost' => $server_renew_cost,
                'new_expires_at' => $newExpiresAtFormatted,
            ],
        ]);

    } catch (Exception $e) {
        $appInstance->ServiceUnavailable('Error renewing server: ' . $e->getMessage(), ['error_code' => 'FAILED_TO_RENEW_SERVER']);
    }
});

// Delete server
$router->post('/api/user/server/(.*)/delete', function (string $id): void {
    App::init();
    $appInstance = App::getInstance(true);
    $appInstance->allowOnlyPOST();
    $session = new Session($appInstance);

    // Get the server first to check ownership
    $server = Servers::getServerPterodactylDetails((int) $id);

    if (!$server) {
        $appInstance->Forbidden('Server not found or you do not have permission to access it', ['error_code' => 'SERVER_NOT_FOUND']);

        return;
    }

    $pterodactylUserId = $session->getInfo(UserColumns::PTERODACTYL_USER_ID, false);
    $owner = $server['attributes']['user'];
    if ($owner != $pterodactylUserId) {
        $appInstance->Forbidden('You do not have permission to access this server', ['error_code' => 'FORBIDDEN']);

        return;
    }
    $serverId = $server['attributes']['id'];

    try {
        // Delete from Pterodactyl first
        Servers::deletePterodactylServer($serverId, false);

        // Only delete from database after successful Pterodactyl deletion
        if (MythicalDash\Chat\Servers\Server::doesServerExistByPterodactylId($serverId)) {
            MythicalDash\Chat\Servers\Server::deleteServerByPterodactylId($serverId);
        }

        global $eventManager;
        $eventManager->emit(ServerEvent::onServerDeleted(), [
            'server' => $serverId,
        ]);
        UserActivities::add(
            $session->getInfo(UserColumns::UUID, false),
            UserActivitiesTypes::$server_delete,
            CloudFlareRealIP::getRealIP(),
            "Deleted server $serverId"
        );
        $appInstance->OK('Server deleted successfully', []);
    } catch (Exception $e) {
        $appInstance->ServiceUnavailable('Error deleting server: ' . $e->getMessage(), ['error_code' => 'FAILED_TO_DELETE_SERVER']);
    }
});

$router->get('/api/user/server/create', function (): void {
    App::init();
    $appInstance = App::getInstance(true);
    $config = $appInstance->getConfig();
    $session = new Session($appInstance);
    $accountToken = $session->SESSION_KEY;

    $locations = Locations::getLocations();
    $categories = EggCategories::getCategories();
    $eggs = Eggs::getAll();

    // Filter locations based on VIP permission
    $hasVipPermission = $session->hasPermission(Permissions::USER_PERMISSION_VIP);
    $locations = array_filter($locations, function ($location) use ($hasVipPermission) {
        // If location is VIP only and user doesn't have VIP permission, exclude it
        if ($location['vip_only'] === 'true' && !$hasVipPermission) {
            return false;
        }

        return true;
    });

    // Filter eggs based on VIP permission
    $eggs = array_filter($eggs, function ($egg) use ($hasVipPermission) {
        // If egg is VIP only and user doesn't have VIP permission, exclude it
        if ($egg['vip_only'] === 'true' && !$hasVipPermission) {
            return false;
        }

        return true;
    });

    // Structure categories with their eggs
    $structuredCategories = array_map(function ($category) use ($eggs) {
        $category['eggs'] = array_filter($eggs, function ($egg) use ($category) {
            return $egg['category'] == $category['id'];
        });

        return $category;
    }, $categories);

    // Filter out categories that have no eggs after VIP filtering
    $structuredCategories = array_filter($structuredCategories, function ($category) {
        return !empty($category['eggs']);
    });

    $pterodactylUserId = User::getInfo($accountToken, UserColumns::PTERODACTYL_USER_ID, false);
    $resources = Servers::getUserTotalResourcesUsage($pterodactylUserId, true);
    $available_resources = User::getInfoArray($accountToken, [
        UserColumns::MEMORY_LIMIT,
        UserColumns::DISK_LIMIT,
        UserColumns::CPU_LIMIT,
        UserColumns::DATABASE_LIMIT,
        UserColumns::BACKUP_LIMIT,
        UserColumns::ALLOCATION_LIMIT,
        UserColumns::SERVER_LIMIT,
    ], []);

    $free_resources = [
        'memory' => $available_resources[UserColumns::MEMORY_LIMIT] - $resources['memory'],
        'disk' => $available_resources[UserColumns::DISK_LIMIT] - $resources['disk'],
        'cpu' => $available_resources[UserColumns::CPU_LIMIT] - $resources['cpu'],
        'databases' => $available_resources[UserColumns::DATABASE_LIMIT] - $resources['databases'],
        'backups' => $available_resources[UserColumns::BACKUP_LIMIT] - $resources['backups'],
        'allocations' => $available_resources[UserColumns::ALLOCATION_LIMIT] - $resources['allocations'],
        'servers' => $available_resources[UserColumns::SERVER_LIMIT] - $resources['servers'],
    ];

    $total_resources = [
        'memory' => $available_resources[UserColumns::MEMORY_LIMIT],
        'disk' => $available_resources[UserColumns::DISK_LIMIT],
        'cpu' => $available_resources[UserColumns::CPU_LIMIT],
        'databases' => $available_resources[UserColumns::DATABASE_LIMIT],
        'backups' => $available_resources[UserColumns::BACKUP_LIMIT],
        'allocations' => $available_resources[UserColumns::ALLOCATION_LIMIT],
        'servers' => $available_resources[UserColumns::SERVER_LIMIT],
    ];

    foreach ($locations as &$location) {
        $location['used_slots'] = Servers::getServerCountByLocation($location['pterodactyl_location_id']);
        $location['image'] = Image::get((int) $location['image_id']);
    }

    foreach ($structuredCategories as &$category) {
        foreach ($category['eggs'] as &$egg) {
            $egg['image'] = Image::get((int) $egg['image_id']);
        }
        $category['image'] = Image::get((int) $category['image_id']);
    }

    $appInstance->OK('Server Creation', [
        'locations' => array_values($locations), // Reset array keys
        'categories' => array_values($structuredCategories), // Reset array keys
        'used_resources' => $resources,
        'total_resources' => $total_resources,
        'free_resources' => $free_resources,
        'has_vip_permission' => $hasVipPermission,
    ]);
});

$router->post('/api/user/server/create', function (): void {
    App::init();
    $appInstance = App::getInstance(true);
    $session = new Session($appInstance);
    $accountToken = $session->SESSION_KEY;
    $config = $appInstance->getConfig();

    // =========================================================================
    // LAYER 1: Basic validation and requirements
    // =========================================================================

    // Check if server creation is globally enabled
    if ($config->getDBSetting(ConfigInterface::ALLOW_SERVERS, 'false') == 'false') {
        $appInstance->BadRequest('Server creation is not allowed', ['error_code' => 'SERVER_CREATION_NOT_ALLOWED']);

        return;
    }

    // Check account linking requirements
    if ($config->getDBSetting(ConfigInterface::FORCE_DISCORD_LINK, 'false') == 'true') {
        $discordLinked = User::getInfo($accountToken, UserColumns::DISCORD_LINKED, false);
        if ($discordLinked == 'false') {
            $appInstance->BadRequest('Discord account linking is required', ['error_code' => 'DISCORD_LINKING_REQUIRED']);

            return;
        }
    }

    if ($config->getDBSetting(ConfigInterface::FORCE_GITHUB_LINK, 'false') == 'true') {
        $githubLinked = User::getInfo($accountToken, UserColumns::GITHUB_LINKED, false);
        if ($githubLinked == 'false') {
            $appInstance->BadRequest('GitHub account linking is required', ['error_code' => 'GITHUB_LINKING_REQUIRED']);

            return;
        }
    }

    if ($config->getDBSetting(ConfigInterface::FORCE_MAIL_LINK, 'false') == 'true') {
        $emailVerified = User::getInfo($accountToken, UserColumns::VERIFIED, false);
        if ($emailVerified == 'false') {
            $appInstance->BadRequest('Email verification is required', ['error_code' => 'EMAIL_VERIFICATION_REQUIRED']);

            return;
        }
    }

    // Validate all required fields are present
    $requiredFields = ['name', 'description', 'location_id', 'category_id', 'egg_id',
        'memory', 'cpu', 'disk', 'databases', 'backups', 'allocations'];

    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field]) || $_POST[$field] === '') {
            $appInstance->BadRequest('Missing required field: ' . $field, ['error_code' => 'MISSING_REQUIRED_FIELDS', 'missing_field' => $field]);

            return;
        }
    }

    // Field length validation
    if (strlen($_POST['name']) > 32) {
        $appInstance->BadRequest('Name must be less than 32 characters', ['error_code' => 'NAME_TOO_LONG']);

        return;
    }

    if (strlen($_POST['description']) > 255) {
        $appInstance->BadRequest('Description must be less than 255 characters', ['error_code' => 'DESCRIPTION_TOO_LONG']);

        return;
    }

    // Process turnstile if enabled
    if ($appInstance->getConfig()->getDBSetting(ConfigInterface::TURNSTILE_ENABLED, 'false') == 'true') {
        if (!isset($_POST['turnstile_response']) || $_POST['turnstile_response'] == '') {
            $appInstance->BadRequest('Bad Request', ['error_code' => 'TURNSTILE_FAILED']);
        }

        $cfTurnstileResponse = $_POST['turnstile_response'];
        if (!Turnstile::validate($cfTurnstileResponse, CloudFlareRealIP::getRealIP(), $config->getDBSetting(ConfigInterface::TURNSTILE_KEY_PRIV, 'XXXX'))) {
            $appInstance->BadRequest('Invalid TurnStile Key', ['error_code' => 'TURNSTILE_FAILED']);
        }
    }

    // Extract and validate numeric values
    $name = $_POST['name'];
    $description = $_POST['description'];
    $location_id = (int) $_POST['location_id'];
    $category_id = (int) $_POST['category_id'];
    $egg_id = (int) $_POST['egg_id'];
    $memory = (int) $_POST['memory'];
    $cpu = (int) $_POST['cpu'];
    $disk = (int) $_POST['disk'];
    $databases = (int) $_POST['databases'];
    $backups = (int) $_POST['backups'];
    $allocations = (int) $_POST['allocations'];

    // Validate numeric ranges
    $numericValidations = [
        ['field' => 'memory', 'value' => $memory, 'min' => 0, 'error_negative' => 'MEMORY_NEGATIVE', 'error_min' => 'MEMORY_TOO_LOW', 'min_value' => 256],
        ['field' => 'cpu', 'value' => $cpu, 'min' => 0, 'error_negative' => 'CPU_NEGATIVE', 'error_min' => 'CPU_TOO_LOW', 'min_value' => 5],
        ['field' => 'disk', 'value' => $disk, 'min' => 0, 'error_negative' => 'DISK_NEGATIVE', 'error_min' => 'DISK_TOO_LOW', 'min_value' => 256],
        ['field' => 'databases', 'value' => $databases, 'min' => 0, 'error_negative' => 'DATABASES_NEGATIVE'],
        ['field' => 'backups', 'value' => $backups, 'min' => 0, 'error_negative' => 'BACKUPS_NEGATIVE'],
        ['field' => 'allocations', 'value' => $allocations, 'min' => 0, 'error_negative' => 'ALLOCATIONS_NEGATIVE', 'error_min' => 'ALLOCATIONS_TOO_LOW', 'min_value' => 1],
    ];

    foreach ($numericValidations as $validation) {
        if ($validation['value'] < 0) {
            $appInstance->BadRequest(ucfirst($validation['field']) . ' cannot be a negative number', ['error_code' => $validation['error_negative']]);

            return;
        }
        if (isset($validation['min_value']) && $validation['value'] < $validation['min_value']) {
            $appInstance->BadRequest(ucfirst($validation['field']) . ' must be at least ' . $validation['min_value'], ['error_code' => $validation['error_min']]);

            return;
        }
    }

    // Validate existence of location, category, and egg
    if (!Locations::exists($location_id)) {
        $appInstance->BadRequest('Location does not exist', ['error_code' => 'LOCATION_DOES_NOT_EXIST']);

        return;
    }

    if (!EggCategories::exists($category_id)) {
        $appInstance->BadRequest('Category does not exist', ['error_code' => 'CATEGORY_DOES_NOT_EXIST']);

        return;
    }

    if (!Eggs::exists($egg_id)) {
        $appInstance->BadRequest('Egg does not exist', ['error_code' => 'EGG_DOES_NOT_EXIST']);

        return;
    }

    $uuid = User::getInfo($accountToken, UserColumns::UUID, false);
    $pterodactylUserId = User::getInfo($accountToken, UserColumns::PTERODACTYL_USER_ID, false);

    // =========================================================================
    // LAYER 2: Comprehensive resource validation with queued resources
    // =========================================================================

    // Get queued resources safely (fallback to 0 if method doesn't exist)
    $queuedResources = [
        'memory' => 0,
        'disk' => 0,
        'cpu' => 0,
        'databases' => 0,
        'backups' => 0,
        'allocations' => 0,
        'servers' => 0,
    ];

    // Check if the method exists before calling it
    if (method_exists('MythicalDash\Chat\Servers\ServerQueue', 'getUserTotalQueuedResources')) {
        $queuedResources = ServerQueue::getUserTotalQueuedResources($uuid);
    }

    $activeResources = Servers::getUserTotalResourcesUsage($pterodactylUserId);

    // Combine active and queued resources for accurate validation
    $totalUsedResources = [
        'memory' => $activeResources['memory'] + $queuedResources['memory'],
        'disk' => $activeResources['disk'] + $queuedResources['disk'],
        'cpu' => $activeResources['cpu'] + $queuedResources['cpu'],
        'databases' => $activeResources['databases'] + $queuedResources['databases'],
        'backups' => $activeResources['backups'] + $queuedResources['backups'],
        'allocations' => $activeResources['allocations'] + $queuedResources['allocations'],
        'servers' => $activeResources['servers'] + $queuedResources['servers'],
    ];

    // Add the new server's resources to calculate total after creation
    $totalAfterCreation = [
        'memory' => $totalUsedResources['memory'] + $memory,
        'disk' => $totalUsedResources['disk'] + $disk,
        'cpu' => $totalUsedResources['cpu'] + $cpu,
        'databases' => $totalUsedResources['databases'] + $databases,
        'backups' => $totalUsedResources['backups'] + $backups,
        'allocations' => $totalUsedResources['allocations'] + $allocations,
        'servers' => $totalUsedResources['servers'] + 1,
    ];

    $available_resources = User::getInfoArray($accountToken, [
        UserColumns::MEMORY_LIMIT,
        UserColumns::DISK_LIMIT,
        UserColumns::CPU_LIMIT,
        UserColumns::DATABASE_LIMIT,
        UserColumns::BACKUP_LIMIT,
        UserColumns::ALLOCATION_LIMIT,
        UserColumns::SERVER_LIMIT,
    ], []);

    // Enhanced resource validation with queued resources included
    $resourceValidations = [
        ['type' => 'memory', 'requested' => $memory, 'total_after' => $totalAfterCreation['memory'], 'limit' => $available_resources[UserColumns::MEMORY_LIMIT], 'error' => 'MAX_MEMORY_LIMIT'],
        ['type' => 'cpu', 'requested' => $cpu, 'total_after' => $totalAfterCreation['cpu'], 'limit' => $available_resources[UserColumns::CPU_LIMIT], 'error' => 'MAX_CPU_LIMIT'],
        ['type' => 'disk', 'requested' => $disk, 'total_after' => $totalAfterCreation['disk'], 'limit' => $available_resources[UserColumns::DISK_LIMIT], 'error' => 'MAX_DISK_LIMIT'],
        ['type' => 'databases', 'requested' => $databases, 'total_after' => $totalAfterCreation['databases'], 'limit' => $available_resources[UserColumns::DATABASE_LIMIT], 'error' => 'MAX_DATABASES_LIMIT'],
        ['type' => 'backups', 'requested' => $backups, 'total_after' => $totalAfterCreation['backups'], 'limit' => $available_resources[UserColumns::BACKUP_LIMIT], 'error' => 'MAX_BACKUPS_LIMIT'],
        ['type' => 'allocations', 'requested' => $allocations, 'total_after' => $totalAfterCreation['allocations'], 'limit' => $available_resources[UserColumns::ALLOCATION_LIMIT], 'error' => 'MAX_ALLOCATIONS_LIMIT'],
        ['type' => 'servers', 'requested' => 1, 'total_after' => $totalAfterCreation['servers'], 'limit' => $available_resources[UserColumns::SERVER_LIMIT], 'error' => 'MAX_SERVER_LIMIT'],
    ];

    foreach ($resourceValidations as $validation) {
        if ($validation['total_after'] > $validation['limit']) {
            $appInstance->BadRequest('This server would exceed your maximum ' . $validation['type'] . ' limit', [
                'error_code' => $validation['error'],
                'limit' => $validation['limit'],
                'current_usage' => $totalUsedResources[$validation['type']],
                'queued_usage' => $queuedResources[$validation['type']],
                'attempted_to_add' => $validation['requested'],
                'total_after_creation' => $validation['total_after'],
            ]);

            return;
        }
    }

    $locationInfo = Locations::get($location_id);
    $eggInfo = Eggs::getById($egg_id);

    // VIP permission checks
    if (isset($locationInfo['vip_only']) && $locationInfo['vip_only'] === 'true' && !$session->hasPermission(Permissions::USER_PERMISSION_VIP)) {
        $appInstance->BadRequest('Location is VIP only', ['error_code' => 'LOCATION_VIP_ONLY']);

        return;
    }

    if (isset($eggInfo['vip_only']) && $eggInfo['vip_only'] === 'true' && !$session->hasPermission(Permissions::USER_PERMISSION_VIP)) {
        $appInstance->BadRequest('Egg is VIP only', ['error_code' => 'EGG_VIP_ONLY']);

        return;
    }

    // Location capacity validation
    if ($locationInfo['slots'] < 1) {
        $appInstance->BadRequest('Location is full', ['error_code' => 'LOCATION_FULL']);

        return;
    }

    $serverCount = MythicalDash\Chat\Servers\Server::getServerCountByLocationId($location_id);
    if ($serverCount >= $locationInfo['slots']) {
        $appInstance->BadRequest('Location is full', ['error_code' => 'LOCATION_FULL', 'server_count' => $serverCount, 'location_slots' => $locationInfo['slots']]);

        return;
    }

    // =========================================================================
    // LAYER 3: Atomic locking and race condition prevention
    // =========================================================================

    // Use file-based locking as a fallback to prevent race conditions
    $lockFile = sys_get_temp_dir() . '/mythicaldash_server_create_' . md5($uuid) . '.lock';
    $lockHandle = fopen($lockFile, 'w+');

    if (!$lockHandle) {
        $appInstance->ServiceUnavailable('Server creation temporarily unavailable', ['error_code' => 'LOCK_UNAVAILABLE']);

        return;
    }

    // Try to acquire exclusive lock with timeout
    $lockAcquired = flock($lockHandle, LOCK_EX | LOCK_NB, $wouldBlock);

    if (!$lockAcquired) {
        if ($wouldBlock) {
            // Another process is already creating a server for this user
            fclose($lockHandle);
            $appInstance->BadRequest('Server creation already in progress', ['error_code' => 'CREATION_IN_PROGRESS']);

            return;
        }
        // Lock failed for some other reason
        fclose($lockHandle);
        $appInstance->ServiceUnavailable('Server creation temporarily unavailable', ['error_code' => 'LOCK_FAILED']);

        return;

    }

    try {
        // Double-check pending items with the lock held
        if (ServerQueue::hasAtLeastOnePendingItem($uuid)) {
            flock($lockHandle, LOCK_UN);
            fclose($lockHandle);
            $appInstance->BadRequest('You already have a pending server creation request', ['error_code' => 'PENDING_SERVER_CREATION_REQUEST']);

            return;
        }

        // Final resource check with lock held (in case something changed)
        $finalQueuedResources = method_exists('MythicalDash\Chat\Servers\ServerQueue', 'getUserTotalQueuedResources')
            ? ServerQueue::getUserTotalQueuedResources($uuid)
            : $queuedResources;

        $finalActiveResources = Servers::getUserTotalResourcesUsage($pterodactylUserId);

        $finalTotalUsed = [
            'memory' => $finalActiveResources['memory'] + $finalQueuedResources['memory'],
            'disk' => $finalActiveResources['disk'] + $finalQueuedResources['disk'],
            'cpu' => $finalActiveResources['cpu'] + $finalQueuedResources['cpu'],
            'databases' => $finalActiveResources['databases'] + $finalQueuedResources['databases'],
            'backups' => $finalActiveResources['backups'] + $finalQueuedResources['backups'],
            'allocations' => $finalActiveResources['allocations'] + $finalQueuedResources['allocations'],
            'servers' => $finalActiveResources['servers'] + $finalQueuedResources['servers'],
        ];

        $finalTotalAfter = [
            'memory' => $finalTotalUsed['memory'] + $memory,
            'disk' => $finalTotalUsed['disk'] + $disk,
            'cpu' => $finalTotalUsed['cpu'] + $cpu,
            'databases' => $finalTotalUsed['databases'] + $databases,
            'backups' => $finalTotalUsed['backups'] + $backups,
            'allocations' => $finalTotalUsed['allocations'] + $allocations,
            'servers' => $finalTotalUsed['servers'] + 1,
        ];

        // Final validation with latest data
        foreach ($resourceValidations as $validation) {
            $type = $validation['type'];
            if ($finalTotalAfter[$type] > $validation['limit']) {
                flock($lockHandle, LOCK_UN);
                fclose($lockHandle);
                $appInstance->BadRequest('Resources changed - this server would now exceed your maximum ' . $type . ' limit', [
                    'error_code' => $validation['error'] . '_CHANGED',
                    'limit' => $validation['limit'],
                    'current_usage' => $finalTotalUsed[$type],
                    'attempted_to_add' => $validation['requested'],
                    'total_after_creation' => $finalTotalAfter[$type],
                ]);

                return;
            }
        }

        // Create server queue item
        $sv = ServerQueue::create($name, $description, $memory, $disk, $cpu, $allocations, $databases, $backups, $location_id, $uuid, $category_id, $egg_id);

        if ($sv == false || $sv == 0) {
            flock($lockHandle, LOCK_UN);
            fclose($lockHandle);
            $appInstance->BadRequest('Failed to create server queue item', ['error_code' => 'FAILED_TO_CREATE_SERVER_QUEUE_ITEM']);

            return;
        }

        // Release the lock
        flock($lockHandle, LOCK_UN);
        fclose($lockHandle);

        // Success handling
        try {
            global $eventManager;
            $eventManager->emit(ServerQueueEvent::onServerQueueCreated(), [
                'id' => $sv,
                'name' => $name,
                'description' => $description,
                'ram' => $memory,
                'disk' => $disk,
                'cpu' => $cpu,
                'ports' => $allocations,
                'databases' => $databases,
                'backups' => $backups,
                'location' => $location_id,
                'user' => $uuid,
                'nest' => $category_id,
                'egg' => $egg_id,
                'status' => 'pending',
            ]);

            UserActivities::add(
                $session->getInfo(UserColumns::UUID, false),
                UserActivitiesTypes::$server_create,
                CloudFlareRealIP::getRealIP(),
                "Created server queue item $sv"
            );

            $appInstance->OK('Server queue item created successfully.', [
                'error_code' => 'SERVER_QUEUE_ITEM_CREATED',
                'server_queue_item' => $sv,
                'server_count' => $serverCount,
                'location_slots' => $locationInfo['slots'],
                'resource_usage' => [
                    'before' => $finalTotalUsed,
                    'after' => $finalTotalAfter,
                    'limits' => $available_resources,
                ],
            ]);

        } catch (Exception $e) {
            // If event emission fails, we should still consider the creation successful
            // but log the error for debugging
            $appInstance->getLogger()->error('Server queue created but event emission failed: ' . $e->getMessage());
            $appInstance->OK('Server queue item created successfully (with event error).', [
                'error_code' => 'SERVER_QUEUE_ITEM_CREATED',
                'server_queue_item' => $sv,
                'warning' => 'Event emission failed',
            ]);
        }

    } catch (Exception $e) {
        // Ensure lock is released on error
        if ($lockHandle) {
            flock($lockHandle, LOCK_UN);
            fclose($lockHandle);
        }
        $appInstance->ServiceUnavailable('Error creating server: ' . $e->getMessage(), ['error_code' => 'SERVER_CREATION_FAILED']);

        return;
    }
});

$router->post('/api/user/queue/(.*)/delete', function (string $id): void {
    App::init();
    $appInstance = App::getInstance(true);
    $appInstance->allowOnlyPOST();
    $session = new Session($appInstance);
    $accountToken = $session->SESSION_KEY;
    $serverQueue = ServerQueue::getByUserAndId($session->getInfo(UserColumns::UUID, false), (int) $id);

    if (empty($serverQueue)) {
        $appInstance->BadRequest('Server queue item not found', ['error_code' => 'SERVER_QUEUE_ITEM_NOT_FOUND', 'server_queue' => $serverQueue]);

        return;
    }

    ServerQueue::delete((int) $serverQueue['id'] ?? 0);
    $appInstance->OK('Server queue item deleted successfully.', ['error_code' => 'SERVER_QUEUE_ITEM_DELETED']);
});

// Get server by ID
$router->get('/api/user/server/(.*)', function (string $id): void {
    App::init();
    $appInstance = App::getInstance(true);
    $appInstance->allowOnlyGET();
    $session = new Session($appInstance);
    $accountToken = $session->SESSION_KEY;
    $pterodactylUserId = User::getInfo($accountToken, UserColumns::PTERODACTYL_USER_ID, false);

    // Get server details
    $server = Servers::getServerPterodactylDetails((int) $id);

    if (empty($server)) {
        $appInstance->Forbidden('Server not found or you do not have permission to access it', ['error_code' => 'SERVER_NOT_FOUND', 'server' => $server]);

        return;
    }

    $pterodactylUserId = $session->getInfo(UserColumns::PTERODACTYL_USER_ID, false);
    $owner = $server['attributes']['user'];
    if ($owner != $pterodactylUserId) {
        $appInstance->Forbidden('You do not have permission to access this server', ['error_code' => 'FORBIDDEN']);

        return;
    }

    // Add additional server information
    $locationId = $server['attributes']['relationships']['location']['attributes']['id'];
    $location = Locations::getLocationByPterodactylLocationId($locationId);
    $server['location'] = $location;

    $eggId = $server['attributes']['relationships']['egg']['attributes']['id'];
    $egg = Eggs::getByPterodactylEggId($eggId);
    $server['service'] = $egg;

    $nestId = $server['attributes']['relationships']['nest']['attributes']['id'];
    $nest = EggCategories::getByPterodactylNestId($nestId);
    $server['category'] = $nest;

    if (MythicalDash\Chat\Servers\Server::doesServerExistByPterodactylId($id)) {
        $serverInfoDb = MythicalDash\Chat\Servers\Server::getByPterodactylId($id);
        $server['mythicaldash'] = $serverInfoDb;
    } else {
        $appInstance->BadRequest('Server not found in MythicalDash', ['error_code' => 'SERVER_NOT_FOUND_IN_MYTHICALDASH']);

        return;
    }

    $appInstance->OK('Server details about server ' . $id, [
        'server' => $server,
    ]);
});
